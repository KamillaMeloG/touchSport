//
//  ViewController.swift
//  TouchSport
//
//  Created by Treinamento on 12/05/18.
//  Copyright © 2018 Treinamento. All rights reserved.
//

import UIKit

class Esportes{
    
    var nome : String
    var informacoes : String?
    var modalidades : [String]?
    var beneficios : [String]?
    var regras : [String]?
    var image: UIImage?
    
    init(nome: String, informacoes: String, modalidades: [String], beneficios: [String], regras: [String], imagem: UIImage){
        self.nome = nome
        self.informacoes = informacoes
        self.modalidades = modalidades
        self.beneficios = beneficios
        self.regras = regras
        self.image = imagem
    }
    
    init(nome: String) {
        self.nome = nome
    }
    
}

class ViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    
    @IBOutlet weak var SportsCollection: UICollectionView!
    
    
    var arrayOfSports: [Esportes] = [Esportes.init(nome: "Futebol", informacoes: "Jogado entre dois times de 11 jogadores cada um e um árbitro que se ocupa da correta aplicação das normas. O objetivo do jogo é deslocar uma bola através do campo para colocá-la dentro da baliza adversária, ação que se denomina gol, A equipe que marca mais gols ao término da partida é a vencedora", modalidades: ["De salão", "De areia"], beneficios: ["1", "2"], regras: ["Regra 1", "Regra 2"], imagem: UIImage()), Esportes.init(nome: "Teste2"), Esportes.init(nome: "Teste3"), Esportes.init(nome: "Teste4"), Esportes.init(nome: "Teste5"), Esportes.init(nome: "Teste6"), Esportes.init(nome: "TEste7"), Esportes.init(nome: "Teste8")]
    
//    var futebol = Esportes()
//    var corrida = Esportes()
//    var surf = Esportes()
//    var tenis = Esportes()
//    var skate = Esportes()
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.arrayOfSports.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = self.SportsCollection.dequeueReusableCell(withReuseIdentifier: "Menu", for: indexPath) as! SportsCollectionViewCell
        
        //cell.sportImage.image = self.arrayOfSports[indexPath.row].image
        cell.nomeEsporte.text = self.arrayOfSports[indexPath.row].nome
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        performSegue(withIdentifier: "EsporteSegue", sender: self.arrayOfSports[indexPath.row])
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "EsporteSegue" {
            let content = sender as! Esportes
            print(content.nome)
            
            let vc = segue.destination as!
            
            
        }
    }
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Futebol
//        futebol.informacoes.insert("Jogado entre dois times de 11 jogadores cada um e um árbitro que se ocupa da correta aplicação das normas. O objetivo do jogo é deslocar uma bola através do campo para colocá-la dentro da baliza adversária, ação que se denomina gol, A equipe que marca mais gols ao término da partida é a vencedora.", at:0)
//        futebol.nome = "Futebol"
//        futebol.modalidades.insert("Futebol de salão", at:0)
//        futebol.modalidades.insert("Futebol de areia", at:1)
//        futebol.modalidades.insert("Futebol de pântano", at:2)
//        futebol.modalidades.insert("Futebol paraolímpico", at:3)
//        futebol.modalidades.insert("Futebol de Pântano", at:4)
//        futebol.modalidades.insert("Futebol Paraolímpico", at:5)
//        futebol.modalidades.insert("Showbol", at:5)
//
//        futebol.beneficios.insert("Diminuição da gordura corporal", at:0)
//        futebol.beneficios.insert("Manutenção do peso", at:1)
//        futebol.beneficios.insert("Aumento da força e da massa muscular", at:2)
//        futebol.beneficios.insert("Aumento da densidade óssea", at:3)
//        futebol.beneficios.insert("Melhora da resistência cardiovascular    ", at:4)
//        futebol.beneficios.insert("Elimina o estresse e a ansiedade", at:5)
//        futebol.beneficios.insert("Diminui a frequência cardíaca em repouso", at:6)
//        futebol.beneficios.insert("Estimula a circulação sanguínea", at:7)
//
//        futebol.regas.insert("Correr atrás da bola", at: 0)
//
//        //Corrida
//        corrida.informacoes.insert("", at:0)
//        corrida.modalidades.insert("", at:0)
//        corrida.beneficios.insert("", at: 0)
//        corrida.regas.insert("", at: 0)
//
//        arrayOfSports.append(futebol)
        
        //arrayOfSports.append(corrida)
        
        SportsCollection.delegate = self
        SportsCollection.dataSource = self
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

